package jvmscompare;

import org.openjdk.jmh.annotations.Mode;
import org.openjdk.jmh.results.format.ResultFormatType;
import org.openjdk.jmh.runner.options.Options;
import org.openjdk.jmh.runner.options.OptionsBuilder;
import org.openjdk.jmh.runner.options.TimeValue;

import java.util.concurrent.TimeUnit;

public interface Constants {

    public static final int SIZE = 1_000_000;

    public static final int WARMUP_ITERATIONS = 2;

    public static final int MEASUREMENT_ITERATIONS = 5;


    public static final Options PARENT_OPTIONS = new OptionsBuilder()
            .forks(2)
            .resultFormat(ResultFormatType.CSV)
            .warmupIterations(WARMUP_ITERATIONS)
            .measurementIterations(MEASUREMENT_ITERATIONS)
            .timeout(TimeValue.seconds(20))
            .mode(Mode.Throughput)
            .timeUnit(TimeUnit.SECONDS).build();

}
